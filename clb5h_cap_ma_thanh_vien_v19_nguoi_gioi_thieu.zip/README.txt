CLB Học tập 5H Sáng — bản cập nhật trường Người giới thiệu

Tệp index.html là website HTML tĩnh. Mở bằng trình duyệt hoặc tải lên nơi bạn đang lưu trữ website.
Thay đổi trong bản này:
- Thay dòng Ghi chú trong mẫu đăng ký bằng trường Người giới thiệu.
- Mặc định là B01 - Bùi Hải Yến; có thể thay bằng mã và tên thành viên đã giới thiệu.
- Thêm lời nhắc nhỏ bên dưới nút sao chép mẫu.
- Đã kiểm tra cú pháp JavaScript bằng node --check.
